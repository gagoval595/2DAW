<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica 2.3 Gabriel</title>
</head>
<body>
    <?php
    $nombre = "Gabriel"; //Nom de la variable nom
    $cognom1 = "Góngora"; //Nom de la variable del primer cognom
    $cognom2 = "Valle"; //Nom de la variable del segon cognom

   
    echo "Nombre: $nombre <br>"; 
    echo "Apellidos: $cognom1 $cognom2 <br>";
    ?>
</body>
</html>