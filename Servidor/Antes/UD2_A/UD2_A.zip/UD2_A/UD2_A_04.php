<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica 2.4 Gabriel</title>
</head>
<body>
    <?php
    $nom ="Gabriel";
    $cognom1 = "Góngora";
    $cognom2 = "Valle";
    $edad = 19;
    $domicili = "C/Sant Francesc Xavier nº46";
    $codi_postal = "03780";
    $tel = 651223532;
    $professio = "Programador Junior";

    echo "Nombre: $nom <br>";
    echo "Cognoms: $cognom1 $cognom2 <br>";
    echo "Edat: $edad <br>";
    echo "Domicili: $domicili <br>";
    echo "Codi Postal: $codi_postal <br>";
    echo "Telèfon: $tel <br>"; 
    echo "Professió: $professio"; 
    ?>
</body>
</html>