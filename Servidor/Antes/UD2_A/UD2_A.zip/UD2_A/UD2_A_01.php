<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica 2.1 Gabriel</title>
</head>
<body>
    <?php
        echo "En un lugar de la mancha ...";
    ?>
    <br>
    <?php
        print "En un lugar de la mancha ..."; 
    ?>
    <br>
    <?=
        "En un lugar de la mancha ...";
    ?>
</body>
</html>