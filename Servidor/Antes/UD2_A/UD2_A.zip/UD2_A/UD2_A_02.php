<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica 2.2 Gabriel</title>
</head>
<body>
<?php
    echo "En un lugar de la mancha ...<br>"; // echo para escribir texto en la pàgina
    print "En un lugar de la mancha ...<br>"; //print para escribir texto igual
?>
<?= // = Para escribir al igual que echo y print
    "En un lugar de la mancha ...";
?>
</body>
</html>