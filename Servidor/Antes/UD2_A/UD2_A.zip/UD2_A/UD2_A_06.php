<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica 2.6 Gabriel</title>
</head>
<body>
    <?php
        define("radi_terra",6378.1);
        define("dist_terra_sol",149597870);

        echo "El radi de la terra es:". radi_terra . "km.<br>";
        echo "La distància de la Terra i el Sol es de: ". dist_terra_sol . "km.";
    ?>
</body>
</html>