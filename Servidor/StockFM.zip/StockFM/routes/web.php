<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\ControladorCanciones;

Route::get('/canciones', [ControladorCanciones::class, 'index'])->name('canciones.index');
Route::get('/canciones/buscar', [ControladorCanciones::class, 'buscar'])->name('canciones.buscar');
Route::get('/canciones/{id}', [ControladorCanciones::class, 'mostrar'])->name('canciones.mostrar');
Route::post('/canciones', [ControladorCanciones::class, 'guardar'])->name('canciones.guardar');
Route::delete('/canciones/{id}', [ControladorCanciones::class, 'eliminar'])->name('canciones.eliminar');

