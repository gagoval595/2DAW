@extends('layouts.app')

@section('content')
  <div class="row">
      <div class="col-md-8 mx-auto">
          <h1 class="text-center mb-4">🎵 Playlist StockFM</h1>

          <form action="{{ route('canciones.buscar') }}" method="GET" class="mb-3">
              <div class="input-group">
                  <input type="text" name="busqueda" class="form-control" placeholder="Buscar canción..." value="{{ request('busqueda') }}">
                  <button type="submit" class="btn btn-primary">Buscar</button>
              </div>
          </form>

          @if($canciones->count() > 0)
              @foreach ($canciones as $cancion)
                  <div class="mb-4">
                      <h5>{{ $cancion->titulo }} - {{ $cancion->artista }}</h5>
                      @if(method_exists($cancion, 'getSpotifyEmbedUrl') && $cancion->getSpotifyEmbedUrl())
                          <iframe src="{{ $cancion->getSpotifyEmbedUrl() }}" width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
                      @else
                          <p class="text-muted">Reproductor no disponible</p>
                      @endif
                  </div>
              @endforeach
          @else
              <p class="text-center">No hay canciones en la playlist.</p>
          @endif
      </div>
  </div>
@endsection
