@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h1 class="text-center mb-4">🎵 Lista de Canciones</h1>

            {{-- Formulario de búsqueda --}}
            <form action="{{ route('canciones.buscar') }}" method="GET" class="mb-3">
                <div class="input-group">
                    <input type="text" name="busqueda" class="form-control" placeholder="Buscar canción..." value="{{ request('busqueda') }}">
                    <button type="submit" class="btn btn-primary">🔍 Buscar</button>
                </div>
            </form>

            {{-- Mensaje de éxito --}}
            @if(session('mensaje'))
                <div class="alert alert-success">
                    {{ session('mensaje') }}
                </div>
            @endif

            {{-- Mostrar lista de canciones --}}
            @if(count($canciones) > 0)
                <ul class="list-group">
                    @foreach ($canciones as $cancion)
                        <li class="list-group-item">
                            <strong>{{ $cancion->titulo }}</strong> - {{ $cancion->artista }}

                            @if($cancion->getSpotifyEmbedUrl())
                                <div class="mt-2">
                                    <iframe style="border-radius:12px" src="{{ $cancion->getSpotifyEmbedUrl() }}"
                                            width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media">
                                    </iframe>
                                </div>
                            @else
                                <p class="text-muted">No hay audio disponible</p>
                            @endif

                            <form action="{{ route('canciones.eliminar', $cancion->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </li>
                    @endforeach
                </ul>
            @else
                <p class="text-muted text-center">No hay canciones registradas.</p>
            @endif

            {{-- Formulario para agregar una nueva canción --}}
            <div class="card mt-4">
                <div class="card-header">➕ Agregar Canción</div>
                <div class="card-body">
                    <form action="{{ route('canciones.guardar') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Título</label>
                            <input type="text" name="titulo" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Artista</label>
                            <input type="text" name="artista" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Álbum (opcional)</label>
                            <input type="text" name="album" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">URL de Spotify</label>
                            <input type="text" name="ruta_audio" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Guardar Canción</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
