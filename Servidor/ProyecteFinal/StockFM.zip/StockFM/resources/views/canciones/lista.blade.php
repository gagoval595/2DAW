@extends('layouts.app')

@section('content')
  <div class="row">
      <div class="col-md-8 mx-auto">
          <h1 class="text-center mb-4">Lista de Canciones</h1>

          
          @if(session('mensaje'))
              <div class="alert alert-success">
                  {{ session('mensaje') }}
              </div>
          @endif

          
          @if($canciones->count() > 0)
              <ul class="list-group mb-4">
                  @foreach ($canciones as $cancion)
                      <li class="list-group-item d-flex justify-content-between align-items-center">
                          <span>{{ $cancion->titulo }} - {{ $cancion->artista }}</span>
                          <form action="{{ route('canciones.eliminar', $cancion->id) }}" method="POST" class="d-inline">
                              @csrf
                              @method('DELETE')
                              <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                          </form>
                      </li>
                  @endforeach
              </ul>
          @else
              <p class="text-center">No has añadido ninguna canción.</p>
          @endif
      </div>
  </div>
@endsection
