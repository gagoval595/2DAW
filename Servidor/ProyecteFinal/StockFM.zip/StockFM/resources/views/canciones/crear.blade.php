@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8 mx-auto">
        <h1 class="text-center mb-4">Añade una canción para nuestra playlist!</h1>
        <div class="card">
            <div class="card-header">Ayúdanos a descubrir música nueva</div>
            <div class="card-body">
                <form action="{{ route('canciones.guardar') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label">Título</label>
                        <input type="text" name="titulo" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Artista</label>
                        <input type="text" name="artista" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Álbum (opcional)</label>
                        <input type="text" name="album" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">URL de Spotify</label>
                        <input type="text" name="ruta_audio" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100">Guardar Canción</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
