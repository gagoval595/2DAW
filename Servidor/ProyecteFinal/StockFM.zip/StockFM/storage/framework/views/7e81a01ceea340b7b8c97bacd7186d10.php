<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <h1 class="text-center mb-4">Añade una canción para nuestra playlist!</h1>
        <div class="card">
            <div class="card-header">Ayúdanos a descubrir música nueva</div>
            <div class="card-body">
                <form action="<?php echo e(route('canciones.guardar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Título</label>
                        <input type="text" name="titulo" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Artista</label>
                        <input type="text" name="artista" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Álbum (opcional)</label>
                        <input type="text" name="album" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">URL de Spotify</label>
                        <input type="text" name="ruta_audio" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100">Guardar Canción</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/StockFM/resources/views/canciones/crear.blade.php ENDPATH**/ ?>