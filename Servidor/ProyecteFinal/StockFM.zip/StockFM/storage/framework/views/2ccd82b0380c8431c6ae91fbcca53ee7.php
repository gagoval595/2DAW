<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-8 mx-auto">
          <h1 class="text-center mb-4">🎵 Playlist StockFM</h1>

          <form action="<?php echo e(route('canciones.buscar')); ?>" method="GET" class="mb-3">
              <div class="input-group">
                  <input type="text" name="busqueda" class="form-control" placeholder="Buscar canción..." value="<?php echo e(request('busqueda')); ?>">
                  <button type="submit" class="btn btn-primary">Buscar</button>
              </div>
          </form>

          <?php if($canciones->count() > 0): ?>
              <?php $__currentLoopData = $canciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cancion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="mb-4">
                      <h5><?php echo e($cancion->titulo); ?> - <?php echo e($cancion->artista); ?></h5>
                      <?php if(method_exists($cancion, 'getSpotifyEmbedUrl') && $cancion->getSpotifyEmbedUrl()): ?>
                          <iframe src="<?php echo e($cancion->getSpotifyEmbedUrl()); ?>" width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
                      <?php else: ?>
                          <p class="text-muted">Reproductor no disponible</p>
                      <?php endif; ?>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
              <p class="text-center">No hay canciones en la playlist.</p>
          <?php endif; ?>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/StockFM/resources/views/canciones/playlist.blade.php ENDPATH**/ ?>