<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h1 class="text-center mb-4">🎵 Lista de Canciones</h1>

            
            <form action="<?php echo e(route('canciones.buscar')); ?>" method="GET" class="mb-3">
                <div class="input-group">
                    <input type="text" name="busqueda" class="form-control" placeholder="Buscar canción..." value="<?php echo e(request('busqueda')); ?>">
                    <button type="submit" class="btn btn-primary">🔍 Buscar</button>
                </div>
            </form>

            
            <?php if(session('mensaje')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('mensaje')); ?>

                </div>
            <?php endif; ?>

            
            <?php if(count($canciones) > 0): ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $canciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cancion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <strong><?php echo e($cancion->titulo); ?></strong> - <?php echo e($cancion->artista); ?>


                            <?php if($cancion->getSpotifyEmbedUrl()): ?>
                                <div class="mt-2">
                                    <iframe style="border-radius:12px" src="<?php echo e($cancion->getSpotifyEmbedUrl()); ?>"
                                            width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media">
                                    </iframe>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">No hay audio disponible</p>
                            <?php endif; ?>

                            <form action="<?php echo e(route('canciones.eliminar', $cancion->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-muted text-center">No hay canciones registradas.</p>
            <?php endif; ?>

            
            <div class="card mt-4">
                <div class="card-header">➕ Agregar Canción</div>
                <div class="card-body">
                    <form action="<?php echo e(route('canciones.guardar')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Título</label>
                            <input type="text" name="titulo" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Artista</label>
                            <input type="text" name="artista" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Álbum (opcional)</label>
                            <input type="text" name="album" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">URL de Spotify</label>
                            <input type="text" name="ruta_audio" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Guardar Canción</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/StockFM/resources/views/canciones/index.blade.php ENDPATH**/ ?>