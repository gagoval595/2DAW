<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-md-8 mx-auto">
          <h1 class="text-center mb-4">Lista de Canciones</h1>

          
          <?php if(session('mensaje')): ?>
              <div class="alert alert-success">
                  <?php echo e(session('mensaje')); ?>

              </div>
          <?php endif; ?>

          
          <?php if($canciones->count() > 0): ?>
              <ul class="list-group mb-4">
                  <?php $__currentLoopData = $canciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cancion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="list-group-item d-flex justify-content-between align-items-center">
                          <span><?php echo e($cancion->titulo); ?> - <?php echo e($cancion->artista); ?></span>
                          <form action="<?php echo e(route('canciones.eliminar', $cancion->id)); ?>" method="POST" class="d-inline">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                          </form>
                      </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          <?php else: ?>
              <p class="text-center">No has añadido ninguna canción.</p>
          <?php endif; ?>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/StockFM/resources/views/canciones/lista.blade.php ENDPATH**/ ?>