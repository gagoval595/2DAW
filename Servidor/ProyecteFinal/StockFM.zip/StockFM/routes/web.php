<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ControladorCanciones;

Route::get('/', [ControladorCanciones::class, 'playlist'])->name('canciones.playlist');
Route::get('/playlist', [ControladorCanciones::class, 'playlist'])->name('canciones.playlist');
Route::get('/lista-canciones', [ControladorCanciones::class, 'lista'])->name('canciones.lista');
Route::get('/agregar-cancion', [ControladorCanciones::class, 'crear'])->name('canciones.crear');
Route::get('/canciones/buscar', [ControladorCanciones::class, 'buscar'])->name('canciones.buscar');
Route::post('/canciones', [ControladorCanciones::class, 'guardar'])->name('canciones.guardar');
Route::delete('/canciones/{id}', [ControladorCanciones::class, 'eliminar'])->name('canciones.eliminar');

