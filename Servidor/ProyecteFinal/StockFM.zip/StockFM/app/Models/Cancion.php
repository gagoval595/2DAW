<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cancion extends Model
{
    use HasFactory;

    protected $table = 'canciones'; 
    protected $fillable = ['titulo', 'artista', 'album', 'ruta_audio'];

    /**
     * Genera la URL embebida de Spotify desde la ruta_audio.
     */
    public function getSpotifyEmbedUrl()
    {
        if (strpos($this->ruta_audio, 'spotify.com') !== false) {
            preg_match('/track\/([a-zA-Z0-9]+)/', $this->ruta_audio, $matches);
            if (isset($matches[1])) {
                return "https://open.spotify.com/embed/track/" . $matches[1];
            }
        }
        return null;
    }
}
