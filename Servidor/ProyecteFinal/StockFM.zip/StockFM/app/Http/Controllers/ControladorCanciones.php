<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cancion;

class ControladorCanciones extends Controller
{
    // Muestra la playlist (índice)
    public function playlist()
    {
        $canciones = Cancion::all();
        return view('canciones.playlist', compact('canciones'));
    }

    // Muestra la lista de canciones añadidas
    public function lista()
    {
        $canciones = Cancion::all();
        return view('canciones.lista', compact('canciones'));
    }

    // Muestra el formulario para agregar una nueva canción
    public function crear()
    {
        return view('canciones.crear');
    }

    // Busca canciones por título o artista
    public function buscar(Request $request)
    {
        $busqueda = $request->input('busqueda');
        $canciones = Cancion::where('titulo', 'like', "%{$busqueda}%")
            ->orWhere('artista', 'like', "%{$busqueda}%")
            ->get();

        return view('canciones.playlist', compact('canciones', 'busqueda'));
    }

    // Guarda una nueva canción
    public function guardar(Request $request)
    {
        $request->validate([
            'titulo'     => 'required|string|max:255',
            'artista'    => 'required|string|max:255',
            'album'      => 'nullable|string|max:255',
            'ruta_audio' => 'required|string|max:500',
        ]);

        Cancion::create($request->all());

        return redirect()->route('canciones.lista')->with('mensaje', 'Canción agregada correctamente.');
    }

    // Elimina una canción
    public function eliminar($id)
    {
        $cancion = Cancion::findOrFail($id);
        $cancion->delete();

        return redirect()->route('canciones.lista')->with('mensaje', 'Canción eliminada correctamente.');
    }
}
