<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('canciones')) {
            Schema::create('canciones', function (Blueprint $table) {
                $table->id();
                $table->string('titulo');
                $table->string('artista');
                $table->string('album')->nullable();
                $table->string('ruta_audio'); 
                $table->timestamps();
            });
        }
    }
    

    public function down(): void
    {
        Schema::dropIfExists('canciones');
    }
};
