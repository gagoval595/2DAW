<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'lian', 'nan', 'mi', 'tang', 'jue', 'gang', 'gang', 'zhuang', 'ge', 'yue', 'wu', 'jian', 'xu', 'shu', 'rong', 'xi',
  0x10 => 'cheng', 'wo', 'jie', 'ge', 'jian', 'qiang', 'huo', 'qiang', 'zhan', 'dong', 'qi', 'jia', 'die', 'zei', 'jia', 'ji',
  0x20 => 'zhi', 'kan', 'ji', 'kui', 'gai', 'deng', 'zhan', 'qiang', 'ge', 'jian', 'jie', 'yu', 'jian', 'yan', 'lu', 'hu',
  0x30 => 'zhan', 'xi', 'xi', 'chuo', 'dai', 'qu', 'hu', 'hu', 'hu', 'e', 'shi', 'ti', 'mao', 'hu', 'li', 'fang',
  0x40 => 'suo', 'bian', 'dian', 'jiong', 'shang', 'yi', 'yi', 'shan', 'hu', 'fei', 'yan', 'shou', 'shou', 'cai', 'zha', 'qiu',
  0x50 => 'le', 'pu', 'ba', 'da', 'reng', 'fan', 'ru', 'zai', 'tuo', 'zhang', 'diao', 'kang', 'yu', 'ku', 'gan', 'shen',
  0x60 => 'cha', 'tuo', 'gu', 'kou', 'wu', 'den', 'qian', 'zhi', 'ren', 'kuo', 'men', 'sao', 'yang', 'niu', 'ban', 'che',
  0x70 => 'rao', 'xi', 'qian', 'ban', 'jia', 'yu', 'fu', 'ao', 'xi', 'pi', 'zhi', 'zhi', 'e', 'den', 'zhao', 'cheng',
  0x80 => 'ji', 'yan', 'kuang', 'bian', 'chao', 'ju', 'wen', 'hu', 'yue', 'jue', 'ba', 'qin', 'dan', 'zheng', 'yun', 'wan',
  0x90 => 'ne', 'yi', 'shu', 'zhua', 'pou', 'tou', 'dou', 'kang', 'zhe', 'pou', 'fu', 'pao', 'ba', 'ao', 'ze', 'tuan',
  0xA0 => 'kou', 'lun', 'qiang', 'yun', 'hu', 'bao', 'bing', 'zhi', 'peng', 'tan', 'bu', 'pi', 'tai', 'yao', 'zhen', 'zha',
  0xB0 => 'yang', 'bao', 'he', 'ni', 'ye', 'di', 'chi', 'pi', 'jia', 'mo', 'mei', 'chen', 'ya', 'chou', 'qu', 'min',
  0xC0 => 'chu', 'jia', 'fu', 'zha', 'zhu', 'dan', 'chai', 'mu', 'nian', 'la', 'fu', 'pao', 'ban', 'pai', 'lin', 'na',
  0xD0 => 'guai', 'qian', 'ju', 'ta', 'ba', 'tuo', 'tuo', 'ao', 'ju', 'zhuo', 'pan', 'zhao', 'bai', 'bai', 'di', 'ni',
  0xE0 => 'ju', 'kuo', 'long', 'jian', 'qia', 'yong', 'lan', 'ning', 'bo', 'ze', 'qian', 'hen', 'kuo', 'shi', 'jie', 'zheng',
  0xF0 => 'nin', 'gong', 'gong', 'quan', 'shuan', 'cun', 'za', 'kao', 'yi', 'xie', 'ce', 'hui', 'pin', 'zhuai', 'shi', 'na',
];
