var searchData=
[
  ['configuration_2ephp_69',['configuration.php',['../configuration_8php.html',1,'']]]
];
