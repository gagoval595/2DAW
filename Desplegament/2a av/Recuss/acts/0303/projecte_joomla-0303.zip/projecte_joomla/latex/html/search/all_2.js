var searchData=
[
  ['configuration_2ephp_63',['configuration.php',['../configuration_8php.html',1,'']]]
];
