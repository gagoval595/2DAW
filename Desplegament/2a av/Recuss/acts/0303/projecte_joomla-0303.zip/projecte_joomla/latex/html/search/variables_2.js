var searchData=
[
  ['joomla_5fminimum_5fphp_134',['JOOMLA_MINIMUM_PHP',['../index_8php.html#ad1efa2e8368efc7138c625978c1543a6',1,'index.php']]]
];
