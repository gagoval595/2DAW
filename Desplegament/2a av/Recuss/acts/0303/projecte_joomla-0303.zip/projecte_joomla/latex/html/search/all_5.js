var searchData=
[
  ['jconfig_66',['JConfig',['../classJConfig.html',1,'']]],
  ['joomla_5fminimum_5fphp_67',['JOOMLA_MINIMUM_PHP',['../index_8php.html#ad1efa2e8368efc7138c625978c1543a6',1,'index.php']]]
];
