var searchData=
[
  ['jconfig_68',['JConfig',['../classJConfig.html',1,'']]]
];
