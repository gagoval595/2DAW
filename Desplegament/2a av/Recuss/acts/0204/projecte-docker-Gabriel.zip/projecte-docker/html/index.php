<?php
try {
    // Connexió a la base de dades
    $servername = "db";
    $username = "user"; 
    $password = "password"; 
    $dbname = "gabriel"; 

    // Crear connexió PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    // Establir el mode d'error per tirar excepcions
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta SQL per obtenir les dades de la taula
    $sql = "SELECT id, nom FROM proves_1402";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Mostrar les dades
    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "ID: " . $row["id"] . " - NOM: " . $row["nom"] . "<br>";
        }
    } else {
        echo "No s'han trobat registres.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
