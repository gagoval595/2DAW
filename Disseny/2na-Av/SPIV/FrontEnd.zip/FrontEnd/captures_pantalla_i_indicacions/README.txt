Els tamanys 1200, 1400 i 1600 són per a agafar referències d'elements (per saber si són X columnes és un container o un container fluid, ...)
En la resta de tamanys poden canviar posicions d'elements, mostrar-se o amagar-se elements, canviar alineacions de coses, ...
Les icones usades són:
Encapçalament:
    - bi bi-search  --> cercador header
Resenyes:     
- bi bi-star-fill --> estrella de resenya plena
- bi bi-star --> estrella de resenya buida
Peu de pàgina:
- bi bi-geo-alt-fill --> icona de l'adreça
- bi bi-telephone-fill --> icona del telèfon
- bi bi-envelope-fill --> icona de l'email
- bi bi-twitter --> icona de Twitter
- bi bi-linkedin --> icona  de linkedin
- bi bi-youtube --> icona de youtube
